import com.soywiz.korag.shader.Program
import com.soywiz.korge.Korge
import com.soywiz.korge.box2d.body
import com.soywiz.korge.box2d.registerBodyWithFixture
import com.soywiz.korge.view.*
import com.soywiz.korim.color.Colors
import com.soywiz.korma.geom.Angle
import com.soywiz.korma.geom.degrees
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.BodyDef
import org.jbox2d.dynamics.BodyType
import org.jbox2d.dynamics.joints.*
import org.jbox2d.pooling.IWorldPool
import org.jbox2d.pooling.normal.DefaultWorldPool

suspend fun kiCartPole(netz : Netzwerk) = Korge(width = 1920, height = 1080, bgcolor = Colors["#2b2b2b"]){
 var hoeheStab=10
  var breiteStab=1
  var hoeheWagen=1
  var breiteWagen= 3

    scale(20,20)

     val Boden = solidRect(500, 5).apply {
         position(0, 45)
         rotation(Angle(0.0))
         registerBodyWithFixture(type = BodyType.STATIC, density = 2, friction = 0.00)
     }
     var cart = solidRect(breiteWagen, hoeheWagen).apply {
         position(25, 44)
         rotation(Angle(0.0))

         registerBodyWithFixture(type = BodyType.DYNAMIC,friction = 0.00,fixedRotation = true)

     }
     var pole = solidRect(breiteStab, hoeheStab).apply {
         position(0, 33)
         rotation(Angle(0.0))
         registerBodyWithFixture(type = BodyType.DYNAMIC,friction = 0.01)
     }
    var def = RevoluteJointDef().apply {
        position(25, 44)
        bodyA= pole.body
        bodyB= cart.body
        localAnchorA= Vec2((breiteStab/2).toFloat(),(hoeheStab).toFloat())
        localAnchorB= Vec2(breiteWagen/2f,hoeheWagen/2f)
        enableMotor= false


    }
var joint= RevoluteJoint(TODO(),def)





var aBewegungen=0
    while(cart.x>2.4 && cart.x<2.3 && pole.rotation.degrees<12&& pole.rotation.degrees>-12&& aBewegungen<5000){

        aBewegungen++
        var cartX= cart.x
        var cartSpeed= cart.body!!.linearVelocityX.toDouble()
       var poleRotation= pole.rotation.degrees
        var poleAngularV= pole.body!!.angularVelocity.toDouble()

       var output= netz.rechnen(doubleArrayOf(cartX,cartSpeed,poleRotation,poleAngularV))

if (output[0]<output[1]) cart.body!!.applyForceToCenter(Vec2(10f,0f))
else cart.body!!.applyForceToCenter(Vec2(-10f,0f))


            }




    netz.fitness= aBewegungen.toDouble()
 }
/*
    print("fitness:")
     println(netz.fitness)
    print("size:")
    println(Snake.size)
    print("bewegungen")
    println(aBewegungen)
    println("")
    println("")*/



