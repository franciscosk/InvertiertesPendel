package com.soywiz.korvi

import kotlin.test.*

class KorviTest {
    @Test
    fun test() {
        assertEquals(true, true)
    }
}
