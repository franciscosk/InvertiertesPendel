package com.soywiz.korvi.internal

internal actual val korviInternal: KorviInternal = NativeKorviInternal()

internal class NativeKorviInternal : KorviInternal() {
}
