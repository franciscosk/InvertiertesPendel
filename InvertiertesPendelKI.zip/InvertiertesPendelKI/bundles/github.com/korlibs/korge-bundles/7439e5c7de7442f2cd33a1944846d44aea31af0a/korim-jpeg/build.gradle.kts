import com.soywiz.korlibs.*

apply<KorlibsPlugin>()

korlibs {
    dependencyProject(":korim")
}
