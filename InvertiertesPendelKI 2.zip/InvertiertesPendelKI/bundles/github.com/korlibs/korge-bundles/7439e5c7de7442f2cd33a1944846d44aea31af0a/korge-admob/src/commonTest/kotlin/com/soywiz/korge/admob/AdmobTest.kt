package com.soywiz.korge.admob

import kotlin.test.Test

class AdmobTest {
	@Test
	fun test() {
	}
}
