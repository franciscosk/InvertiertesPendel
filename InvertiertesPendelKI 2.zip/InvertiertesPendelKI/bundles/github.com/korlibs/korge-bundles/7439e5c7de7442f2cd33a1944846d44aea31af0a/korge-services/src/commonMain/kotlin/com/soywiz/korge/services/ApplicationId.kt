package com.soywiz.korge.services

import com.soywiz.korge.service.ServiceBaseId

class ApplicationId() : ServiceBaseId()
