import com.soywiz.klock.TimeSpan
import com.soywiz.korag.shader.Program
import com.soywiz.korge.Korge
import com.soywiz.korge.box2d.body
import com.soywiz.korge.box2d.nearestBox2dWorld
import com.soywiz.korge.box2d.registerBody
import com.soywiz.korge.box2d.registerBodyWithFixture
import com.soywiz.korge.time.delay
import com.soywiz.korge.view.*
import com.soywiz.korim.color.Colors
import com.soywiz.korma.geom.Angle
import com.soywiz.korma.geom.degrees
import kotlinx.coroutines.isActive
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.BodyDef
import org.jbox2d.dynamics.BodyType
import org.jbox2d.dynamics.joints.*
import org.jbox2d.pooling.IWorldPool
import org.jbox2d.pooling.normal.DefaultWorldPool

 suspend fun kiCartPole(netz : Netzwerk) = Korge(width = 1000, height = 1000, bgcolor = Colors["#2b2b2b"]){
 var hoeheStab=100
  var breiteStab=10
  var hoeheWagen=10
  var breiteWagen= 100



     val Boden = solidRect(800, 50).apply {
         position(0, 450)
         rotation(Angle(0.0))
         registerBodyWithFixture(type = BodyType.STATIC, density = 2, friction = 0.00)
     }
     var cart = solidRect(breiteWagen, hoeheWagen).apply {
         position(250, 420)
         rotation(Angle(0.0))
         color=Colors.RED
         registerBodyWithFixture(type = BodyType.DYNAMIC,friction = 0.00,fixedRotation = true)

     }
     var pole = solidRect(breiteStab, hoeheStab).apply {
         position(250, 310)
         rotation(Angle(0.0) )
         registerBodyWithFixture(type = BodyType.DYNAMIC,friction = 0.01)
         color=Colors.BLUE
     }
    var def = RevoluteJointDef().apply {
        position(250, 440)
        bodyA= pole.body
        bodyB= cart.body
        localAnchorA= Vec2((breiteStab/2/*+pole.x*/).toFloat(),(hoeheStab /*+pole.y*/).toFloat())
        localAnchorB= Vec2(breiteWagen/2f/*+cart.x.toFloat()*/,hoeheWagen/2f/*+cart.y.toFloat()*/)
        enableMotor= false



    }
//var joint= RevoluteJoint(this.nearestBox2dWorld.pool,def)
nearestBox2dWorld.createJoint(def)




var aBewegungen=0
    while(cart.x>0 && cart.x<500 && pole.rotation.degrees<12&& pole.rotation.degrees>-12&& aBewegungen<5000){
delay(TimeSpan(20.0))

        aBewegungen++
        var cartX= cart.x
        var cartSpeed= cart.body!!.linearVelocityX.toDouble()
       var poleRotation= pole.rotation.degrees
        var poleAngularV= pole.body!!.angularVelocity.toDouble()
        println(cartX)
        println(cartSpeed)
        println(poleRotation)
        println(poleAngularV)
        println(aBewegungen)
        println()
       var output= netz.rechnen(doubleArrayOf(cartX,cartSpeed,poleRotation,poleAngularV))

if (output[0]<output[1]) cart.body!!.applyForceToCenter(Vec2(10f,0f))
else cart.body!!.applyForceToCenter(Vec2(-10f,0f))


            }




    netz.fitness= aBewegungen.toDouble()

 }
/*
    print("fitness:")
     println(netz.fitness)
    print("size:")
    println(Snake.size)
    print("bewegungen")
    println(aBewegungen)
    println("")
    println("")*/



