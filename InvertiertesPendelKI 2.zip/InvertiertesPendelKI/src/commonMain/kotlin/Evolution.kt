
import com.soywiz.korma.geom.Angle
import kotlin.random.Random


suspend fun evolution(
    population: Array<Netzwerk>, aKinder:Int,
    mutationRate: Double) : Array<Netzwerk> {

    /** 1. fitness herausfinden**/
     //playMario(population)
for(i in population){
    kiCartPole(i)
}


    /** die fittesten netzwerke auswählen**/
    population.sortByDescending{ it.fitness }
    var eltern= Array<Netzwerk>(10){i ->population[i]}
//eltern.forEach{ println(it.fitness.toInt())}
    println(eltern[0].fitness.toInt())
    /** neue population erstellen und diese mit kindern der besten netzwerke füllen**/

    var neuePopulation: Array<Netzwerk> = Array<Netzwerk>(aKinder) { Netzwerk(population[0].schichten) }



    //var neuePopulation: Array<Netzwerk> = Array<Netzwerk>(population.size) { Netzwerk(population[0].schichten) }
    for(netzwerk in eltern.indices) {
        for (a in 0..aKinder/eltern.size - 2) {
            neuePopulation[netzwerk*aKinder/eltern.size+a].netz = Array(population[netzwerk].schichten.size - 1) { i ->
                Array(population[netzwerk].schichten[i]) { j ->
                    Neuron(
                        DoubleArray(population[netzwerk].schichten[i + 1]) { k -> population[netzwerk].netz[i][j].synapsen[k] +  (Random.nextDouble() - 0.5) * mutationRate/population[netzwerk].fitness},
                        0.0,
                        population[netzwerk].netz[i][j].bias + (Random.nextDouble() - 0.5) *  (Random.nextDouble() - 0.5) * mutationRate/population[netzwerk].fitness
                    )
                }
            }
            neuePopulation[(netzwerk + 1) * aKinder / population.size - 1].netz =
                Array(population[netzwerk].schichten.size - 1) { i ->
                    Array(population[netzwerk].schichten[i]) { j ->
                        Neuron(
                            DoubleArray(population[netzwerk].schichten[i + 1]) { k -> population[netzwerk].netz[i][j].synapsen[k] },
                            0.0,
                            population[netzwerk].netz[i][j].bias
                        )
                    }
                }
        }}
    return neuePopulation

/*
    var AI1childmax : IntArray= IntArray(population.size)

    for(aaa in population.indices){
        for(aab in population.indidces){
            if(fitness[aab] > fitness[AI1childmax[aaa]]) AI1childmax[aaa] = aab
        }
        fitness[AI1childmax[aaa]] = 0.0

    }
    return Array<Netzwerk>(population.size){i -> neuePopulation[AI1childmax[i]]}
    return neuePopulation
    */

}


